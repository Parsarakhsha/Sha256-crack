import csv
import hashlib
my_dict = {}
hash_dict = {}
for num in range(1000, 10000):
    num_str = str(num)
    hashed_num = hashlib.sha256(num_str.encode()).hexdigest()
    hash_dict[hashed_num] = num
with open("pap.csv") as fhand:
    text = csv.reader(fhand)
    for row in text:
        my_dict[row[0]] = row[1]
search_hash = my_dict.get("javad")
if search_hash in hash_dict.keys():
    password = hash_dict[search_hash]
    print("javad is", password)
else:
    print("noting found.")
search_hash = my_dict.get("milad")
if search_hash in hash_dict.keys():
    password = hash_dict[search_hash]
    print("milad is", password)
else:
    print("noting found.")
search_hash = my_dict.get("tahmine")
if search_hash in hash_dict.keys():
    password = hash_dict[search_hash]
    print("tahmine is", password)
else:
    print("noting found.")
search_hash = my_dict.get("niloofar")
if search_hash in hash_dict.keys():
    password = hash_dict[search_hash]
    print("niloofar is", password)
else:
    print("noting found.")


